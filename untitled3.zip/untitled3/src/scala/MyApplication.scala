import javafx.fxml.{FXML, FXMLLoader, Initializable}
import javafx.scene.control.Button
import javafx.scene.{Parent, Scene}
import javafx.stage.Stage

import java.net.URL
import java.util.ResourceBundle


class MyApplication extends Initializable {



  override def initialize(location: URL, resources: ResourceBundle): Unit = {
  /**  val button: Button = new Button
    button.setText("Click me!")
    button.setOnAction(_ => println("Button clicked!"))

  */
  }
}